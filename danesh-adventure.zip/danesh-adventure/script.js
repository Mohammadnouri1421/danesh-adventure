const questions = [
  {stage:0,category:"🧮 جزیره ریاضی",image:"assets/math.svg",title:"حاصل جمع ۳ + ۴ چند می‌شود؟",options:["۵","۶","۷","۸"],answer:2,explanation:"۳ تا به‌علاوه ۴ تا می‌شود ۷ تا."},
  {stage:0,category:"🧮 جزیره ریاضی",image:"assets/math.svg",title:"اگر ۱۰ ستاره داشته باشیم و ۳ ستاره بدهیم، چند ستاره می‌ماند؟",options:["۶","۷","۸","۹"],answer:1,explanation:"۱۰ منهای ۳ برابر با ۷ است."},
  {stage:0,category:"🧮 جزیره ریاضی",image:"assets/math.svg",title:"کدام عدد از همه بزرگ‌تر است؟",options:["۱۲","۸","۱۵","۱۱"],answer:2,explanation:"عدد ۱۵ از ۱۲، ۸ و ۱۱ بزرگ‌تر است."},
  {stage:1,category:"📚 جنگل فارسی",image:"assets/persian.svg",title:"کدام واژه هم‌معنی «شاد» است؟",options:["غمگین","خوشحال","خسته","ترسیده"],answer:1,explanation:"شاد و خوشحال معنی یکسانی دارند."},
  {stage:1,category:"📚 جنگل فارسی",image:"assets/persian.svg",title:"کدام گزینه نام یک حیوان است؟",options:["مداد","دفتر","گنجشک","پنجره"],answer:2,explanation:"گنجشک یک پرنده و از گروه حیوانات است."},
  {stage:1,category:"📚 جنگل فارسی",image:"assets/persian.svg",title:"کدام واژه مخالف «بزرگ» است؟",options:["بلند","کوچک","سنگین","زیبا"],answer:1,explanation:"مخالف بزرگ، کوچک است."},
  {stage:2,category:"🔬 سیاره علوم",image:"assets/science.svg",title:"گیاه برای رشد به کدام مورد نیاز دارد؟",options:["نور خورشید","پلاستیک","شیشه","آهن"],answer:0,explanation:"گیاهان برای رشد به آب، نور و مواد مغذی نیاز دارند."},
  {stage:2,category:"🔬 سیاره علوم",image:"assets/science.svg",title:"ما روی کدام سیاره زندگی می‌کنیم؟",options:["مریخ","زهره","زمین","مشتری"],answer:2,explanation:"خانه ما سیاره زیبای زمین است."},
  {stage:2,category:"🔬 سیاره علوم",image:"assets/science.svg",title:"آب خالص در حالت مایع چه رنگی است؟",options:["قرمز","آبی پررنگ","سبز","بی‌رنگ"],answer:3,explanation:"آب خالص در حالت مایع بی‌رنگ و شفاف است."}
];

const lessons = [
  {id:0,key:"math",name:"جزیره ریاضی",icon:"🧮",image:"assets/math.svg",desc:"فکر کن و معماها رو حل کن"},
  {id:1,key:"persian",name:"جنگل فارسی",icon:"📚",image:"assets/persian.svg",desc:"واژه‌ها و معنی‌ها رو پیدا کن"},
  {id:2,key:"science",name:"سیاره علوم",icon:"🔬",image:"assets/science.svg",desc:"شگفتی‌های جهان رو کشف کن"}
];

const questionsByLesson = lessons.map(l => questions.filter(q => q.stage === l.id));

const STORAGE_KEY = "daneshAdventure.stats.v1";

let currentLesson = null;
let activeQuestions = [];
let currentQuestion = 0, score = 0, correctAnswers = 0, answered = false;

const $ = id => document.getElementById(id);
const screens = [$("homeScreen"), $("gameScreen"), $("resultScreen")];

function faNumber(value){return String(value).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[Number(d)]);}
function showScreen(target){screens.forEach(s=>s.classList.remove("active"));target.classList.add("active");window.scrollTo({top:0,behavior:"smooth"});}

/* ---------- ذخیره‌سازی (localStorage) ---------- */
function emptyStat(){return {bestScore:0,bestCorrect:0,totalCorrect:0,plays:0,stars:0,lastPlayed:null};}
function defaultStats(){return {lessons:{math:emptyStat(),persian:emptyStat(),science:emptyStat()},full:emptyStat()};}
let stats = defaultStats();
function loadStats(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return defaultStats();
    const parsed = JSON.parse(raw);
    const base = defaultStats();
    base.lessons.math    = Object.assign(base.lessons.math,    parsed.lessons && parsed.lessons.math);
    base.lessons.persian = Object.assign(base.lessons.persian, parsed.lessons && parsed.lessons.persian);
    base.lessons.science = Object.assign(base.lessons.science, parsed.lessons && parsed.lessons.science);
    base.full            = Object.assign(base.full, parsed.full);
    return base;
  }catch(e){ return defaultStats(); }
}
function saveStats(){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(stats)); }catch(e){} }
function clearStats(){ stats = defaultStats(); saveStats(); renderBadges(); }
function getBucket(key){ return key === "full" ? stats.full : stats.lessons[key]; }

function recordResult(key, correct, total, finalScore, stars){
  const b = getBucket(key);
  if(!b) return;
  b.plays = (b.plays||0)+1;
  b.totalCorrect = (b.totalCorrect||0)+correct;
  b.lastPlayed = new Date().toISOString();
  if(finalScore > (b.bestScore||0)) b.bestScore = finalScore;
  if(correct > (b.bestCorrect||0)) b.bestCorrect = correct;
  if(stars > (b.stars||0)) b.stars = stars;
  saveStats();
}

function renderBadges(){
  lessons.forEach(l=>{
    const el = $("badge"+l.id);
    if(!el) return;
    const s = stats.lessons[l.key];
    if(!s || !s.plays){ el.classList.remove("has"); el.textContent = "هنوز بازی نشده"; }
    else { el.classList.add("has"); el.innerHTML = "⭐ <b>"+faNumber(s.bestScore)+"</b> · "+faNumber(s.stars)+" ستاره"; }
  });
}

/* ---------- آمار صفحه ---------- */
function updateStats(){
  $("headerScore").textContent = faNumber(score);
  $("sideScore").textContent = faNumber(score);
  $("correctCount").textContent = faNumber(correctAnswers);
  const total = activeQuestions.length;
  $("progressFill").style.width = (currentQuestion/total*100)+"%";
  $("progressText").textContent = "سؤال "+faNumber(Math.min(currentQuestion+1,total))+" از "+faNumber(total);
}
function updateLevels(stage){
  for(let i=0;i<3;i++){
    const el = $("level"+i);
    el.classList.remove("current","done");
    el.querySelector(".level-state").textContent = i<stage?"✓":i===stage?"●":"🔒";
    if(i<stage) el.classList.add("done"); else if(i===stage) el.classList.add("current");
  }
}
function setupSidebar(){
  if(currentLesson === "full"){
    $("levelMap").hidden = false;
    $("singleLessonLabel").hidden = true;
    $("mapLabel").textContent = "نقشهٔ ماجراجویی";
  } else {
    const l = lessons[currentLesson];
    $("levelMap").hidden = true;
    $("singleLessonLabel").hidden = false;
    $("singleLessonIcon").textContent = l.icon;
    $("singleLessonName").textContent = l.name;
    $("mapLabel").textContent = "درس در حال آزمون";
  }
}

/* ---------- کنترل اجرا ---------- */
function beginRun(){
  currentQuestion = 0; score = 0; correctAnswers = 0; answered = false;
  setupSidebar();
  updateStats();
  showScreen($("gameScreen"));
  renderQuestion();
}
function startFull(){ currentLesson = "full"; activeQuestions = questions; beginRun(); }
function startLesson(id){ currentLesson = id; activeQuestions = questionsByLesson[id]; beginRun(); }
function retake(){ beginRun(); }

function renderQuestion(){
  if(currentQuestion >= activeQuestions.length){ showResults(); return; }
  answered = false;
  const q = activeQuestions[currentQuestion];
  $("category").textContent = q.category;
  $("questionImage").src = q.image; $("questionImage").alt = q.category;
  $("questionTitle").textContent = q.title;
  $("questionNumber").textContent = "سؤال "+faNumber(currentQuestion+1)+" از "+faNumber(activeQuestions.length);
  $("feedback").className = "feedback"; $("feedback").textContent = "";
  $("nextBtn").classList.remove("show");
  const box = $("answers"); box.replaceChildren();
  q.options.forEach((option,index)=>{
    const button = document.createElement("button");
    button.className = "answer";
    button.textContent = faNumber(index+1)+" ـ "+option;
    button.addEventListener("click",()=>selectAnswer(index));
    box.appendChild(button);
  });
  if(currentLesson === "full") updateLevels(q.stage);
  updateStats();
}

function showSparkles(count=20){
  const symbols = ["⭐","✨","🌟","💛","🎉"];
  for(let i=0;i<count;i++){
    const el = document.createElement("span"); el.className = "sparkle";
    el.textContent = symbols[Math.floor(Math.random()*symbols.length)];
    el.style.left = (8+Math.random()*84)+"vw"; el.style.top = (20+Math.random()*55)+"vh";
    el.style.setProperty("--dx",(Math.random()*180-90)+"px"); el.style.animationDelay = (Math.random()*.35)+"s";
    $("effects").appendChild(el); setTimeout(()=>el.remove(),1600);
  }
}

function selectAnswer(index){
  if(answered) return; answered = true;
  const q = activeQuestions[currentQuestion];
  const buttons = $("answers").querySelectorAll("button");
  const feedback = $("feedback");
  buttons.forEach(b=>b.disabled = true);
  buttons[q.answer].classList.add("correct");
  if(index === q.answer){
    score += 10; correctAnswers++;
    feedback.textContent = "🎉 آفرین! پاسخ درست است. "+q.explanation;
    feedback.className = "feedback show good";
    showSparkles(22);
  } else {
    buttons[index].classList.add("wrong");
    feedback.textContent = "💪 اشکالی ندارد! پاسخ درست: "+q.options[q.answer]+" ـ "+q.explanation;
    feedback.className = "feedback show bad";
  }
  updateStats();
  $("nextBtn").classList.add("show");
  $("nextBtn").textContent = currentQuestion === activeQuestions.length-1 ? "دیدن نتیجه 🏆" : "سؤال بعدی ←";
}

function nextQuestion(){
  if(!answered) return;
  currentQuestion++;
  if(currentQuestion >= activeQuestions.length) showResults();
  else renderQuestion();
}

function showResults(){
  showScreen($("resultScreen"));
  const total = activeQuestions.length;
  const percentage = Math.round(correctAnswers/total*100);
  const stars = Math.round(correctAnswers/total*5);
  $("finalScore").textContent = faNumber(score);
  $("finalCorrect").textContent = faNumber(correctAnswers)+" از "+faNumber(total);
  $("finalStars").textContent = "⭐ "+faNumber(stars);

  const isFull = currentLesson === "full";
  const key = isFull ? "full" : lessons[currentLesson].key;
  const label = isFull ? "ماجراجویی کامل" : lessons[currentLesson].name;
  $("resultLesson").textContent = label;

  recordResult(key, correctAnswers, total, score, stars);
  const s = getBucket(key);
  $("lessonBest").textContent = "⭐ "+faNumber(s.bestScore);
  $("lessonPlays").textContent = "این درس "+faNumber(s.plays)+" بار بازی شده";

  if(percentage >= 80){
    $("resultTitle").textContent = isFull ? "قهرمان سرزمین دانش!" : "قهرمان "+label+"!";
    $("resultMessage").textContent = "فوق‌العاده بود! تو یک ماجراجوی دانا هستی و با موفقیت از "+label+" عبور کردی.";
    showSparkles(40);
  } else if(percentage >= 50){
    $("resultTitle").textContent = "آفرین، ماجراجوی پرتلاش!";
    $("resultMessage").textContent = "خیلی خوب پیش رفتی! با کمی تمرین بیشتر می‌توانی ستاره‌های بیشتری جمع کنی.";
  } else {
    $("resultTitle").textContent = "شروع یک یادگیری تازه!";
    $("resultMessage").textContent = "هر اشتباه یک فرصت یادگیری است. دوباره بازی کن و این بار رکورد خودت را بهتر کن.";
  }
  $("headerScore").textContent = faNumber(score);
  renderBadges();
}

/* ---------- شروع ---------- */
stats = loadStats();
renderBadges();

$("startBtn").addEventListener("click", startFull);
$("nextBtn").addEventListener("click", nextQuestion);
$("restartBtn").addEventListener("click", retake);
$("homeBtn").addEventListener("click", ()=>{ showScreen($("homeScreen")); renderBadges(); });
$("clearBtn").addEventListener("click", ()=>{ if(confirm("اطلاعات ذخیره‌شده برای همیشه پاک شود؟")){ clearStats(); } });
document.querySelectorAll("[data-lesson]").forEach(el=>{
  el.addEventListener("click", ()=>startLesson(Number(el.getAttribute("data-lesson"))));
});
